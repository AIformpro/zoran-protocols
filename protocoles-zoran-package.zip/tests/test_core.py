from pzoran.core import ProtocoleZoran

def test_send_message():
    proto = ProtocoleZoran()
    assert "Message envoyé" in proto.send_message("test")
