class ProtocoleZoran:
    def __init__(self):
        pass

    def send_message(self, content):
        return f"Message envoyé : {content}"

    def sync_glyphs(self):
        return "Synchronisation des glyphes effectuée"

    def handshake(self, peer):
        return f"Handshake sécurisé avec {peer}"
