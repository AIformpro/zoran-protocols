from pzoran.core import ProtocoleZoran

proto = ProtocoleZoran()
print(proto.send_message("Bonjour"))
print(proto.sync_glyphs())
print(proto.handshake("agentX"))
